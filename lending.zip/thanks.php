<!DOCTYPE html>
<head>
    <meta charset="utf-8">

    <title>Территория роста</title>

    <meta name="description" content="Blue One Page Creative HTML5 Template">
    <meta name="keywords" content="one page, single page, onepage, responsive, parallax, creative, business, html5, css3, css3 animation">
    <meta name="author" content="Muhammad Morshed">

    <!-- CSS
    ================================================== -->
    <link rel="stylesheet" href="css/page.css">
    <link rel="shortcut icon" href="/img/favicon.ico" type="image/x-icon">

</head>

    <body>

    <div class = "main-form">
        <p>  Благодарим вас за отклик! </p>
        <p>  Мы свяжемся с вами в течении суток. </p>
        <form action = '/' method="post">
            <button> Назад на сайт </button>
        </form>


    </div>



    </body>
</html>
